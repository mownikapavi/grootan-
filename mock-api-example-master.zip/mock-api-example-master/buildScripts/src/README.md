Run this command to start a mock api and generate a db.json file to this directory:
npm run start-mockapi
