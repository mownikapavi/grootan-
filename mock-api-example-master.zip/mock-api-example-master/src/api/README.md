This directory will contain the mock API when you run this command:
npm run start-mockapi
